{
    'name': 'Jasman Contact Import',
    'version': '1.0',
    'summary': 'Scripts for importing contact data',
    'category': 'Import Scripts',
    'author': 'Odoo Inc.',
    'maintainer': 'Odoo Inc.',
    'website': 'www.odoo.com',
    'license': 'OPL-1',
    'description': """
    
    Task: 3527999
    Developer: EUVM
    """
}
